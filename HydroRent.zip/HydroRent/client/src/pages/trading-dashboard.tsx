import { TradingDashboard } from '@/components/TradingDashboard';

const TradingDashboardPage = () => {
  return <TradingDashboard />;
};

export default TradingDashboardPage;
